# plugin.video.novaflix/resources/lib/gui/ids.py
"""Control IDs shared by the Python controllers and the XML layouts (M12).
tests/test_layouts.py checks every ID listed in WINDOW_IDS exists in its layout."""

SIDEBAR = 100
SIDEBAR_SETTINGS = 101
MENU_GROUP = 9100      # group around 100 + 101: the menu is open while it has focus (Cinematic UI)
HERO_PLAY = 201
HERO_INFO = 202
HERO_PLOT = 203     # the hero plot: focusable so it can scroll through
HERO_DOTS = 204     # the hero dots: Left / Right step through the featured titles
HERO_FOCUS = (201, 202, 203, 204)
HOME_ROWS = (300, 310, 320, 330)
HOME_RETRY = 340
GRID = 400               # title pages: two rows under the focused-title peek
GRID_TILES = 401         # tile pages (Search, Genres, My TorBox): the full-height grid
GRIDS = (GRID, GRID_TILES)
GRID_EMPTY_ACTION = 410  # "Browse Trending Now" on an empty personal list
GENRE_TAB_FILMS = 411    # Genres: Films / Shows tabs
GENRE_TAB_SHOWS = 412
RELATED_ROWS = (800, 810, 820, 830, 840, 850)
SHOW_PLAY = 500
SHOW_FAVOURITE = 501
SHOW_RELATED = 502
SHOW_SEASON = 503   # season picker (TV)
SHOW_EPISODES = 510
SHOW_PLOT = 520     # the plot: focusable so it can scroll through
SOURCES_LIST = 600
CONFIRM_YES = 700
CONFIRM_NO = 701
PROGRESS_BAR = 710
PROGRESS_CANCEL = 711
MENU_LIST = 720
PROMPT_BUTTON = 9000

ACTION_BACK = {9, 10, 92}        # parent dir, previous menu, back
ACTION_CONTEXT = {117}           # context menu / hold OK
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_DOWN = 4
ACTION_MOVES = {1, 2, 3, 4, 5, 6}  # left, right, up, down, page up, page down

# Each task that adds a layout adds its entry here.
WINDOW_IDS = {
    "novaflix-prompt.xml": [PROMPT_BUTTON],
    "novaflix-login.xml": [9000],
    "novaflix-confirm.xml": [CONFIRM_YES, CONFIRM_NO],
    "novaflix-progress.xml": [PROGRESS_BAR, PROGRESS_CANCEL],
    "novaflix-sources.xml": [SOURCES_LIST],
    "novaflix-menu.xml": [MENU_LIST],
    "novaflix-show.xml": [SHOW_PLAY, SHOW_FAVOURITE, SHOW_RELATED, SHOW_SEASON, SHOW_EPISODES, SHOW_PLOT],
    "novaflix-app.xml": [SIDEBAR, SIDEBAR_SETTINGS, MENU_GROUP, HERO_PLAY, HERO_INFO, HERO_PLOT, HERO_DOTS, *HOME_ROWS, HOME_RETRY, GRID, GRID_TILES, GRID_EMPTY_ACTION,
                         GENRE_TAB_FILMS, GENRE_TAB_SHOWS,
                         *RELATED_ROWS],
}
